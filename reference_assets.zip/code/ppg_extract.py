"""Extract locked epoch features from public PPG and ECG annotations.
Usage: python code/ppg_extract.py --raw-dir /path/to/downloaded/files
Raw data are downloaded separately by download_ppg.py. No tuning or training.
"""
from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from scipy.signal import periodogram
import wfdb
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--raw-dir',type=Path,required=True);args=p.parse_args()
raw=args.raw_dir;data=ROOT/'source_data'
manifest=json.loads((data/'ppg_download_manifest.json').read_text())
for f in manifest['files']:
 path=raw/f['filename']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==f['sha256'],path
rows=[];inventory=[]
for rec in (raw/'RECORDS').read_text().split():
 h=wfdb.rdheader(str(raw/rec));channel=h.sig_name.index('pleth_3');fs=h.fs
 sig=wfdb.rdrecord(str(raw/rec),channels=[channel]).p_signal[:,0]
 ann=wfdb.rdann(str(raw/rec),'atr');peaks=np.asarray([t for t,s in zip(ann.sample,ann.symbol) if s=='N'])/fs
 assert set(ann.symbol)=={'N'},set(ann.symbol)
 n=int(10*fs);participant,activity=rec.split('_')
 inventory.append({'record':rec,'participant':participant,'activity':activity,'fs':fs,'samples':len(sig),'complete_epochs':len(sig)//n,'analysed_seconds':10*(len(sig)//n),'trailing_seconds':(len(sig)%n)/fs,'reference_caution':int(rec=='s13_walk')})
 for i in range(len(sig)//n):
  x=sig[i*n:(i+1)*n];start=i*10;end=start+10
  finite=np.all(np.isfinite(x)) and np.ptp(x)>0
  est=quality=float('nan')
  if finite:
   f,power=periodogram(x,fs=fs,window='hann',detrend='linear',nfft=4*n)
   band=(f>=.7)&(f<=3.5);fb=f[band];pb=power[band]
   if pb.sum()>0:
    peak=fb[np.argmax(pb)];est=60*peak
    quality=pb[np.abs(fb-peak)<=.15+1e-10].sum()/pb.sum()
  rr=peaks[(peaks>=start)&(peaks<end)];diff=np.diff(rr)
  valid=len(rr)>=3 and np.all((diff>=.25)&(diff<=2)) and rr[0]-start<=2 and end-rr[-1]<=2
  reason='available' if valid else 'annotation_continuity_check'
  if rec=='s13_walk':valid=False;reason='repository_ecg_noise_caution'
  ref=60*(len(rr)-1)/(rr[-1]-rr[0]) if valid else float('nan')
  rows.append({'record':rec,'participant':participant,'activity':activity,'epoch':i,'start_s':start,'end_s':end,'duration_s':10,'ppg_hr_bpm':est,'spectral_concentration':quality,'reference_available':int(valid),'reference_hr_bpm':ref,'reference_status':reason})
 print(rec,len(sig)//n,flush=True)
for name,values in [('ppg_epochs.csv',rows),('ppg_record_inventory.csv',inventory)]:
 with (data/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)
(data/'ppg_feature_provenance.json').write_text(json.dumps({'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'epochs_sha256':hashlib.sha256((data/'ppg_epochs.csv').read_bytes()).hexdigest(),'number_of_epochs':len(rows),'all_raw_input_hashes_verified':True},indent=2))
