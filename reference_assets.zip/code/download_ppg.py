"""Download original PTT PPG inputs (438 MB); requires network access.
Usage: python code/download_ppg.py --raw-dir /path/to/raw
"""
from pathlib import Path
import argparse,json,hashlib,urllib.request,concurrent.futures
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--raw-dir',type=Path,required=True);args=p.parse_args();args.raw_dir.mkdir(parents=True,exist_ok=True)
items=json.loads((ROOT/'source_data/ppg_download_manifest.json').read_text())['files']
def get(x):
 path=args.raw_dir/x['filename']
 if not path.exists():
  with urllib.request.urlopen(x.get('mirror_url',x['url']),timeout=120) as r:path.write_bytes(r.read())
 assert hashlib.sha256(path.read_bytes()).hexdigest()==x['sha256'],path
 return x['filename']
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for name in ex.map(get,items):print(name)
