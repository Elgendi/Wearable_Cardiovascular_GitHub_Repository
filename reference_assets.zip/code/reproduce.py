"""Reproduce published-data recalculations and explicitly constructed examples.

Run from any directory: python code/reproduce.py
No downloads, fitting, random sampling, or unpublished participant data.
"""
from pathlib import Path
import csv
import json
import itertools
import shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'source_data'
FIG = ROOT / 'figures'
TABLE = ROOT / 'tables'
for path in (DATA, FIG, TABLE):
    path.mkdir(exist_ok=True)
shutil.copy2(ROOT/'reference_assets/Author_Figure1.png', FIG/'Fig1.png')
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'pdf.fonttype': 42, 'ps.fonttype': 42,
                     'axes.labelcolor': '#22313F', 'text.color': '#22313F'})
BLUE, TEAL, ORANGE, GREY = '#28668B', '#007F78', '#C46929', '#A6AFB7'

def save(fig, name):
    fig.savefig(FIG / f'{name}.pdf', bbox_inches='tight')
    fig.savefig(FIG / f'{name}.png', dpi=320, bbox_inches='tight')
    plt.close(fig)

def runs(mask):
    return [sum(1 for _ in g) for value, g in itertools.groupby(mask) if not value]

def blind_fraction(mask, k):
    """Fraction of within-record k-bin starts with no released bin."""
    if not 1 <= k <= len(mask):
        raise ValueError('k must be within the record')
    return sum(max(0, g-k+1) for g in runs(mask)) / (len(mask)-k+1)

def brute_blind(mask, k):
    return np.mean([not np.any(mask[s:s+k]) for s in range(len(mask)-k+1)])

# Verify the gap formula independently by enumeration for all short masks.
for n in range(1, 9):
    for mask in itertools.product([False, True], repeat=n):
        for k in range(1, n+1):
            assert np.isclose(blind_fraction(mask, k), brute_blind(mask, k))

# Published Table 3: preserve its totals independently of rounded patient rows.
pub = json.loads((DATA / 'reissenberger2023_table3.json').read_text())
e = pub['ecg_af_evaluable_min']
tp = pub['ppg_true_positive_min']
outside = pub['ecg_af_outside_evaluable_min']
total = e + outside
missed_assessed = e-tp
fractions = np.array([tp, missed_assessed, outside])/total
assert np.isclose(fractions.sum(), 1)
summary = {'evidence_type': 'secondary arithmetic from published tables',
           'ecg_documented_af_minutes': total,
           'pooled_correct_fraction_within_evaluable': tp/e,
           'correct_fraction_of_documented_af_time': tp/total,
           'assessed_but_not_correct_fraction_of_documented_af_time': missed_assessed/total,
           'outside_evaluable_fraction_of_documented_af_time': outside/total,
           'fixed_evaluable_support_ceiling': e/total,
           'maximum_improvement_on_fixed_support': (e-tp)/total}
with (DATA / 'reissenberger2023_table2.csv').open() as f:
    patients = [{k: int(v) for k, v in r.items()} for r in csv.DictReader(f)]
assert len(patients) == 25 and len({r['published_patient_id'] for r in patients}) == 25
for r in patients:
    t, v, a = r['monitoring_min'], r['joint_evaluable_min'], r['ecg_af_evaluable_min']
    assert 0 <= r['ppg_true_positive_min'] <= a <= v <= t
    r.update(coverage=v/t, observed_ecg_af_fraction=a/v,
             lower=a/t, upper=(a+t-v)/t, width=1-v/t)
with (DATA / 'patient_burden_bounds.csv').open('w', newline='') as f:
    w=csv.DictWriter(f, fieldnames=list(patients[0]));w.writeheader();w.writerows(patients)
summary['table2_sums'] = {k: sum(r[k] for r in patients) for k in
    ['ecg_af_evaluable_min', 'ppg_true_positive_min', 'monitoring_min', 'joint_evaluable_min']}
summary['table3_minus_table2_ecg_minutes'] = e-summary['table2_sums']['ecg_af_evaluable_min']
summary['table3_minus_table2_tp_minutes'] = tp-summary['table2_sums']['ppg_true_positive_min']
summary['patient_bound_width_median'] = float(np.median([r['width'] for r in patients]))
summary['patient_bound_width_range'] = [min(r['width'] for r in patients),max(r['width'] for r in patients)]
summary['patients_width_above_0_10'] = sum(r['width']>0.10 for r in patients)

# Constructed masks; all released estimates are stipulated to be correct.
n=100
alternating=np.arange(n)%2==0
blocked=np.arange(n)<50
assert alternating.sum()==blocked.sum()==50
example=[]
for k in range(1, 101):
    example.append({'duration_bins':k, 'alternating_blind_fraction':blind_fraction(alternating,k),
                    'blocked_blind_fraction':blind_fraction(blocked,k)})
with (DATA/'constructed_gap_curves.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(example[0]));w.writeheader();w.writerows(example)
with (DATA/'constructed_masks.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['minute_index','alternating_release','blocked_release'])
    w.writerows((i+1,int(alternating[i]),int(blocked[i])) for i in range(n))
summary['constructed_10_min_blind_fractions'] = [blind_fraction(alternating,10),blind_fraction(blocked,10)]
summary['constructed_longest_gaps_min'] = [max(runs(alternating)),max(runs(blocked))]

# Figure 1 is supplied artwork, copied unchanged from reference_assets.
# Figure 2: original conceptual vector artwork.
fig=plt.figure(figsize=(7.1,5.6));ax=fig.add_axes([0,0,1,1]);ax.axis('off')
def box(x,y,w,h,label,color='#F0F4F6',size=10):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012',linewidth=.8,
                 edgecolor='#D2DCE2',facecolor=color,transform=ax.transAxes))
    ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=size,transform=ax.transAxes)
def arrow(x1,y1,x2,y2):
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),xycoords='axes fraction',
                arrowprops={'arrowstyle':'->','color':'#74838B','lw':1.2})
ax.text(.02,.97,'a  Preserve the intended monitoring period',weight='bold',fontsize=11)
box(.19,.79,.62,.10,'Intended time T\nDefine endpoint, schedule and permitted latency')
arrow(.50,.78,.25,.69);arrow(.50,.78,.77,.69)
box(.04,.57,.42,.11,'Released in time', '#E6F1F4')
box(.58,.57,.36,.11,'Unavailable output U\nKeep reason and timestamps','#EEF0F2')
arrow(.17,.56,.15,.47);arrow(.34,.56,.43,.47)
box(.02,.35,.26,.11,'Reference assessed\nAcceptable G / error F','#E2F0EC',9)
box(.33,.35,.24,.11,'No valid reference\nUnassessed H','#FAEEE1',9)
ax.text(.75,.40,'G + F + H + U = 1',ha='center',fontsize=11,weight='bold')
ax.text(.02,.26,'b  Match the evidence to the claim',weight='bold',fontsize=11)
box(.02,.05,.28,.14,'Released-value accuracy\nError + assessment coverage',size=9)
box(.36,.05,.28,.14,'Episode surveillance\nGap lengths + observation\nof reference episodes',size=9)
box(.70,.05,.28,.14,'Full-period burden\nIdentification interval +\nmissingness assumptions',size=9)
save(fig,'Fig2')

# Figure 3: published data, no inferred individual missing-event times.
fig=plt.figure(figsize=(7.1,7.0));gs=fig.add_gridspec(2,2,height_ratios=[1,2.4],hspace=.55,wspace=.55)
ax=fig.add_subplot(gs[0,:])
left=0
labels=['Correctly identified\nAF time','Not correctly identified\nwithin evaluable time','AF outside\nevaluable time']
for f,c,l in zip(fractions,[TEAL,ORANGE,GREY],labels):
    ax.barh(0,100*f,left=left,color=c,height=.42)
    ax.text(left+50*f,0,f'{100*f:.1f}%',ha='center',va='center',color='white',weight='bold',fontsize=11)
    ax.text(left+50*f,-.38,l,ha='center',va='top',fontsize=8)
    left+=100*f
ax.set_xlim(0,100);ax.set_ylim(-.85,.6);ax.set_yticks([]);ax.set_xticks([])
for sp in ax.spines.values():sp.set_visible(False)
ax.set_title('a  Where did the ECG-documented AF time go?',loc='left',weight='bold',pad=12)
ax.text(0,.49,f'{total:,} AF minutes; published Table 3',fontsize=9)
ax=fig.add_subplot(gs[1,0]);vals=[tp/e,tp/total,e/total]
ax.bar(range(3),np.array(vals)*100,color=[BLUE,TEAL,GREY],width=.65)
for i,v in enumerate(vals):ax.text(i,v*100+2,f'{v*100:.1f}%',ha='center',weight='bold')
ax.set_ylim(0,100);ax.set_ylabel('Fraction of the stated AF-time denominator (%)')
ax.set_xticks(range(3),['Correct /\nevaluable\nAF time','Correct / all\ndocumented\nAF time','Ceiling with\nfixed\nsupport'])
ax.tick_params(axis='x',labelsize=8)
ax.set_title('b  Denominators change\n    the claim',loc='left',weight='bold',fontsize=10)
ax.text(.5,-.23,'73.7% is a pooled duration ratio; it is not\nthe source study’s 85.1% model estimate.',transform=ax.transAxes,
        ha='center',va='top',fontsize=8)
ax=fig.add_subplot(gs[1,1]);sortedp=sorted(patients,key=lambda r:r['coverage'])
for i,r in enumerate(sortedp):
    ax.plot([100*r['lower'],100*r['upper']],[i,i],color=GREY,lw=2)
    ax.scatter([100*r['observed_ecg_af_fraction']],[i],c=BLUE,s=12,zorder=3)
ax.set_yticks(range(25),[r['published_patient_id'] for r in sortedp],fontsize=7)
ax.set_xlim(-2,102);ax.set_xlabel('AF burden (%)');ax.set_ylabel('Published patient ID (ordered by coverage)')
ax.set_title('c  What observed summaries\n    identify',loc='left',weight='bold',fontsize=10)
ax.text(.5,-.23,'Lines: bounds from Table 2 summaries only.\nDots: ECG burden within evaluable time.',transform=ax.transAxes,
        ha='center',va='top',fontsize=8)
fig.subplots_adjust(bottom=.16,top=.94,left=.11,right=.97)
save(fig,'Fig3')

# Figure 4: exact equal-coverage counterexample, with a shared episode overlay.
from matplotlib.patches import Rectangle, Patch
fig=plt.figure(figsize=(7.8,7.2))
fig.text(.12,.965,'a  Equal coverage can hide an entire episode',weight='bold',fontsize=11)
fig.text(.12,.932,'Both records: 50% coverage; released outputs stipulated correct',fontsize=9)
ax=fig.add_axes([.12,.60,.67,.265])
ax.set_xlim(0,100);ax.set_ylim(-.27,2.05)
ax.axvspan(65,75,color=ORANGE,alpha=.10,zorder=0)
for mask,y,label in [(alternating,1.13,'Distributed gaps'),(blocked,.12,'One long gap')]:
    ax.add_patch(Rectangle((0,y),100,.32,facecolor='#DFE4E8',edgecolor='none'))
    for i,v in enumerate(mask):
        if v: ax.add_patch(Rectangle((i,y),1,.32,facecolor=TEAL,edgecolor='none'))
    ax.add_patch(Rectangle((65,y-.045),10,.41,facecolor='none',edgecolor=ORANGE,lw=1.6,zorder=5))
    ax.text(0,y+.48,label,weight='bold',fontsize=9)
ax.text(70,1.92,'Same 10-min episode',ha='center',fontsize=8.5,color=ORANGE)
ax.plot([65,75],[1.73,1.73],color=ORANGE,lw=1.3)
ax.text(102,1.30,'5 min observed',va='center',fontsize=8.5,color=TEAL,weight='bold',clip_on=False)
ax.text(102,.28,'0 min observed',va='center',fontsize=8.5,color=ORANGE,weight='bold',clip_on=False)
ax.set_yticks([]);ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Intended monitoring time (min)',fontsize=9)
for sp in ['left','top','right']:ax.spines[sp].set_visible(False)
ax.legend(handles=[Patch(facecolor=TEAL,label='Released'),Patch(facecolor='#DFE4E8',label='Unavailable')],
          loc='upper left',bbox_to_anchor=(-.012,-.34),ncol=2,frameon=False,fontsize=8,borderaxespad=0)
ax=fig.add_axes([.12,.115,.335,.29]);ks=np.arange(1,51)
ax.plot(ks,[100*blind_fraction(blocked,int(k)) for k in ks],color=ORANGE,label='One long gap',lw=2)
ax.plot(ks,[100*blind_fraction(alternating,int(k)) for k in ks],color=TEAL,label='Distributed gaps',lw=2)
ax.axvline(10,color='#D4DBE0',lw=1,ls=':',zorder=0)
ax.scatter([10,10],[100*blind_fraction(blocked,10),0],color=[ORANGE,TEAL],s=28,zorder=4)
ax.annotate('45.1% (41/91)',xy=(10,45.05),xytext=(15,36),fontsize=8,color=ORANGE,
            arrowprops={'arrowstyle':'-','lw':.7,'color':ORANGE})
ax.text(13,3,'0% (0/91)',fontsize=8,color=TEAL)
ax.set_xlim(1,50);ax.set_ylim(-3,60);ax.set_xlabel('Candidate episode duration (min)',fontsize=8.5);ax.set_ylabel('Completely blind start positions (%)',fontsize=8.5)
ax.legend(frameon=False,fontsize=7.5,loc='upper right');ax.set_title('b  Gap timing changes\n    observation opportunity',loc='left',weight='bold',fontsize=10,pad=10)
ax=fig.add_axes([.635,.115,.335,.29]);c=np.linspace(0,1,101)
ax.plot(c*100,(1-c)*100,color=BLUE,lw=2);ax.axhline(10,color=GREY,ls='--',lw=1);ax.axvline(90,color=GREY,ls='--',lw=1)
ax.scatter([90],[10],color=BLUE,s=28);ax.set_xlabel('Error-free state observation (%)',fontsize=8.5);ax.set_ylabel('Burden identification width (pp)',fontsize=8.5)
ax.set_xlim(0,100);ax.set_ylim(0,100);ax.set_title('c  Precision requires\n    observation',loc='left',weight='bold',fontsize=10,pad=10)
ax.text(.38,.71,'10-pp width requires\nat least 90% observation\nwhen unobserved states\nare unconstrained.',transform=ax.transAxes,fontsize=7.3,
        bbox={'facecolor':'white','edgecolor':'none','alpha':.97,'pad':2})
save(fig,'Fig4')

# Exact outputs and LaTeX table rows used in the supplement.
(DATA/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (TABLE/'patient_rows.tex').open('w') as f:
    for r in patients:
        f.write(f"{r['published_patient_id']} & {r['ecg_af_evaluable_min']} & {r['monitoring_min']} & {r['joint_evaluable_min']} & "
                f"{100*r['coverage']:.1f} & {100*r['observed_ecg_af_fraction']:.1f} & "
                f"{100*r['lower']:.1f}--{100*r['upper']:.1f} \\\\\n")
print(json.dumps(summary,indent=2))
