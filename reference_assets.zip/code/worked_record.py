"""Generate a fictional, fully specified monitoring record and claim checks."""
from pathlib import Path
import csv,json,datetime
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'source_data'
A=[1,1,0,0,1,1,1,0,1,1,0,1];B=[1,1,1,1,1,0,1,1,1,0,1,1]
reference=[0,0,1,1,1,None,1,0,0,None,0,0]
output=[0,0,None,None,1,1,0,None,0,0,None,0]
reasons={2:'motion_rejection',3:'motion_rejection',7:'nonwear',10:'late_delivery'}
rows=[];t0=datetime.datetime(2000,1,1,tzinfo=datetime.timezone.utc)
for i,(a,b) in enumerate(zip(A,B)):
 status='U' if not a else 'H' if not b else 'G' if output[i]==reference[i] else 'F'
 rows.append({'example_id':'FICTIONAL_001','opportunity_id':i+1,'start_utc':(t0+datetime.timedelta(minutes=i)).isoformat(),'end_utc':(t0+datetime.timedelta(minutes=i+1)).isoformat(),'duration_s':60,'timely_release':a,'release_latency_s':90 if i==10 else 0 if a else '', 'allowed_latency_s':30,'release_reason':reasons.get(i,'released'),'reference_available':b,'reference_state':'' if reference[i] is None else reference[i],'released_state':'' if output[i] is None else output[i],'status':status,'processing_version':'illustration_v1'})
with (D/'worked_status_record.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
counts={s:sum(r['status']==s for r in rows) for s in 'GFHU'}
assert counts=={'G':5,'F':1,'H':2,'U':4}
starts=[i for i in range(11) if not any(A[i:i+2])]
summary={'fictional':True,'period_min':12,'status_minutes':counts,'release_coverage':8/12,'reference_coverage':10/12,'joint_assessment_coverage':6/12,'conditional_error':1/6,'unacceptable_fraction_of_intended_time':1/12,'incorrect_overall_coverage_times_conditional_error':(8/12)*(1/6),'longest_unavailable_run_min':2,'two_minute_blind_start_fraction':len(starts)/11,'assessed_released_reference_AF_minutes':2,'released_assessed_state_burden_bounds':[2/12,8/12],'all_available_reference_AF_minutes':4,'all_reference_burden_bounds':[4/12,6/12]}
(D/'worked_status_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (ROOT/'tables/worked_status_rows.tex').open('w') as f:
 for r in rows:
  i=r['opportunity_id'];f.write(f"{i-1}--{i} & {r['timely_release']} & {r['reference_available']} & {r['reference_state'] if r['reference_state']!='' else '--'} & {r['released_state'] if r['released_state']!='' else '--'} & {r['status']} \\\\\n")
assert summary['unacceptable_fraction_of_intended_time']!=summary['incorrect_overall_coverage_times_conditional_error']
print(json.dumps(summary,indent=2))
