from pathlib import Path
import urllib.request,concurrent.futures,json,hashlib
root=Path(__file__).resolve().parents[1]/'source_data/afdb';root.mkdir(exist_ok=True)
base='https://physionet.org/files/afdb/1.0.0/'
records=urllib.request.urlopen(base+'RECORDS',timeout=45).read();(root/'RECORDS').write_bytes(records)
names=['notes.txt','RECORDS']+[r+'.'+e for r in records.decode().split() for e in ['hea','atr']]
def get(name):
 try:
  b=urllib.request.urlopen(base+name,timeout=45).read();(root/name).write_bytes(b)
  return {'filename':name,'url':base+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 except Exception as e:return {'filename':name,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex: results=list(ex.map(get,names))
(root/'download_manifest.json').write_text(json.dumps({'retrieved':'2026-09-18','source_doi':'10.13026/C2MW2D','license':'Open Data Commons Attribution License v1.0','files':results},indent=2))
print(json.dumps(results,indent=2))
