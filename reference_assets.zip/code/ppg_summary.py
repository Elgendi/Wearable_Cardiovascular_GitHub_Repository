"""Offline supporting analysis from traceable, per-epoch measured-signal features."""
from pathlib import Path
import csv,json,hashlib,itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'source_data'
provenance=json.loads((D/'ppg_feature_provenance.json').read_text())
assert hashlib.sha256((D/'ppg_epochs.csv').read_bytes()).hexdigest()==provenance['epochs_sha256']
with (D/'ppg_epochs.csv').open() as f:rows=list(csv.DictReader(f))
for r in rows:
 for k in ['epoch','start_s','end_s','duration_s','ppg_hr_bpm','spectral_concentration','reference_available','reference_hr_bpm']:r[k]=float(r[k])
subjects=sorted({r['participant'] for r in rows},key=lambda x:int(x[1:]));thresholds=[0,.3,.5,.7]
def metrics(rr,threshold):
 a=np.array([np.isfinite(r['ppg_hr_bpm']) and r['spectral_concentration']>=threshold for r in rr]);b=np.array([bool(r['reference_available']) for r in rr])
 x=np.array([r['ppg_hr_bpm'] for r in rr]);y=np.array([r['reference_hr_bpm'] for r in rr]);joint=a&b
 n=len(rr);good=joint&(np.abs(x-y)<=5);bad=joint&~good
 result={'epochs':n,'released':int(a.sum()),'reference':int(b.sum()),'assessed_releases':int(joint.sum()),'G':good.sum()/n,'F':bad.sum()/n,'H':(a&~b).sum()/n,'U':(~a).sum()/n,'coverage':a.mean(),'reference_coverage':b.mean(),'mae_bpm':float(np.mean(np.abs(x[joint]-y[joint]))) if joint.any() else float('nan'),'conditional_error':bad.sum()/joint.sum() if joint.any() else float('nan')}
 assert np.isclose(sum(result[k] for k in ['G','F','H','U']),1)
 if joint.any():
  est=float(np.mean(x[joint]-y[joint]));shift=float(np.mean(y[joint])-np.mean(y[b]));total=float(np.mean(x[joint])-np.mean(y[b]));assert np.isclose(est+shift,total)
 else:est=shift=total=float('nan')
 result.update(estimator_signed_error_bpm=est,reference_selection_shift_bpm=shift,total_mean_difference_bpm=total)
 gaps=[]
 for record in sorted({r['record'] for r in rr}):
  m=[v for r,v in zip(rr,a) if r['record']==record]
  gaps.extend(10*sum(1 for _ in g) for value,g in itertools.groupby(m) if not value)
 result['longest_gap_s']=max(gaps,default=0)
 return result
participant=[];activity=[]
for t in thresholds:
 for s in subjects:
  rr=[r for r in rows if r['participant']==s]
  participant.append({'participant':s,'threshold':t,**metrics(rr,t)})
  for act in ['sit','walk','run']:
   subset=[r for r in rr if r['activity']==act]
   activity.append({'participant':s,'activity':act,'threshold':t,**metrics(subset,t)})
def write(name,rr):
 with (D/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
write('ppg_participant_summary.csv',participant);write('ppg_activity_summary.csv',activity)
summary={'participants':len(subjects),'records':len({r['record'] for r in rows}),'epochs':len(rows),'analysed_hours':len(rows)*10/3600,'reference_assessable_epochs':sum(r['reference_available'] for r in rows),'thresholds':{}}
for t in thresholds:
 rr=[r for r in participant if r['threshold']==t]
 summary['thresholds'][str(t)]={key:float(np.nanmedian([r[key] for r in rr])) for key in ['coverage','mae_bpm','conditional_error','reference_selection_shift_bpm','longest_gap_s','G','F','H','U']}
 summary['thresholds'][str(t)]['mean_participant_mae_bpm']=float(np.nanmean([r['mae_bpm'] for r in rr]))
 summary['thresholds'][str(t)]['participants_with_assessed_releases']=sum(r['assessed_releases']>0 for r in rr)
 summary['thresholds'][str(t)]['median_absolute_selection_shift_bpm']=float(np.nanmedian([abs(r['reference_selection_shift_bpm']) for r in rr]))
 summary['thresholds'][str(t)]['activity_median_coverage']={act:float(np.median([r['coverage'] for r in activity if r['threshold']==t and r['activity']==act])) for act in ['sit','walk','run']}
# Frozen contrast: permissive baseline versus 0.7 gate; report all prespecified gates.
baseline={r['participant']:r for r in participant if r['threshold']==0}
strict={r['participant']:r for r in participant if r['threshold']==.7}
paired=[]
for s in subjects:
 a,b=baseline[s],strict[s]
 paired.append({'participant':s,'mae_change_bpm':b['mae_bpm']-a['mae_bpm'],'coverage_change':b['coverage']-a['coverage'],'selection_shift_bpm':b['reference_selection_shift_bpm'],'total_mean_difference_bpm':b['total_mean_difference_bpm']})
write('ppg_paired_contrast.csv',paired)
summary['strict_vs_baseline']={'participants_with_lower_mae':sum(r['mae_change_bpm']<0 for r in paired),'median_paired_mae_change_bpm':float(np.nanmedian([r['mae_change_bpm'] for r in paired])),'median_absolute_selection_shift_bpm':float(np.nanmedian([abs(r['selection_shift_bpm']) for r in paired]))}
(D/'ppg_summary.json').write_text(json.dumps(summary,indent=2))
# Figure 5: measured waveform example, separate accuracy, coverage and selection.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
colors=['#526879','#28668B','#007F78','#C46929'];fig,axs=plt.subplots(2,2,figsize=(7.2,7.0))
ax=axs[0,0]
for s in subjects:
 rr=[next(r for r in participant if r['threshold']==t and r['participant']==s) for t in thresholds]
 ax.plot(thresholds,[r['mae_bpm'] for r in rr],color='#BBC5CC',alpha=.7,lw=.7,zorder=1)
vals=[summary['thresholds'][str(t)]['mae_bpm'] for t in thresholds]
ax.plot(thresholds,vals,'o-',color='#28668B',lw=2,zorder=3);ax.set_ylabel('Released HR MAE (bpm)');ax.set_title('a  Conditional accuracy',loc='left',weight='bold',fontsize=10);ax.text(.98,.95,f'Median: {vals[0]:.2f} to {vals[-1]:.2f} bpm',transform=ax.transAxes,ha='right',va='top',fontsize=8,color='#28668B')
ax=axs[0,1]
for act,col,label in zip(['sit','walk','run'],['#28668B','#007F78','#C46929'],['Sitting','Walking','Running']):
 vals=[summary['thresholds'][str(t)]['activity_median_coverage'][act]*100 for t in thresholds]
 ax.plot(thresholds,vals,'o-',color=col,label=label,lw=2)
ax.set_ylabel('Released epochs (%)');ax.set_ylim(-3,105);ax.set_title('b  Which activity is represented?',loc='left',weight='bold',fontsize=10);ax.legend(frameon=False,fontsize=8)
for ax in axs[0]:ax.set_xlabel('Spectral-concentration threshold');ax.set_xticks(thresholds)
ax=axs[1,0];ss=sorted(subjects,key=lambda s:strict[s]['reference_selection_shift_bpm'])
for i,s in enumerate(ss):
 v=strict[s]['reference_selection_shift_bpm'];ax.plot([0,v],[i,i],color='#BBC5CC',lw=1.4);ax.scatter(v,i,color='#C46929',s=15)
ax.axvline(0,color='#526879',lw=.8);ax.set_yticks(range(len(ss)),ss,fontsize=7);ax.set_ylabel('Participant');ax.set_xlabel('Selected minus all assessed\nreference HR (bpm)');ax.set_title('c  Selection alone changes the mean',loc='left',weight='bold',fontsize=10)
ax=axs[1,1]
# Directly show every participant's intended-time partition at threshold 0.7.
for i,s in enumerate(ss):
 left=0
 for key,col in zip(['G','F','H','U'],['#007F78','#C46929','#D5B571','#DEE4E8']):
  ax.barh(i,strict[s][key]*100,left=left,color=col,height=.8,label=key if i==0 else None);left+=strict[s][key]*100
ax.set_yticks([]);ax.set_xlim(0,100);ax.set_xlabel('Intended recorded time (%)');ax.set_title('d  Preserve all observation states',loc='left',weight='bold',fontsize=10)
ax.legend(frameon=False,ncol=4,loc='upper center',bbox_to_anchor=(.5,-.18),fontsize=8,handlelength=1,columnspacing=1)
fig.subplots_adjust(left=.09,right=.98,bottom=.16,top=.91,hspace=.66,wspace=.38)
fig.suptitle('Measured finger PPG; fixed offline estimator and quality gates',fontsize=11,weight='bold',y=.99)
fig.text(.5,.012,'Panels a-b: participant medians (a also shows individuals). Panels c-d: gate 0.7; same participant order.\nG: within 5 bpm; F: above 5 bpm; H: unassessed; U: no released estimate. No clinical threshold is proposed.',ha='center',fontsize=7.5)
fig.savefig(ROOT/'figures/Fig5.pdf',bbox_inches='tight');fig.savefig(ROOT/'figures/Fig5.png',dpi=320,bbox_inches='tight');plt.close(fig)
print(json.dumps(summary,indent=2))
