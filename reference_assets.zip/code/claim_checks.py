"""Research reporting checks. Thresholds must come from the intended use.
A 'met' result applies only to the stated requirement on the supplied record;
it is not clinical validation, prospective performance, or a treatment decision.
"""
import json,math
from pathlib import Path

def result(requirement,status,estimate,reason):
 return dict(requirement=requirement,status=status,estimate=estimate,reason=reason)
def released_error(g,f,h,*,maximum_error):
 """Bound error over ALL released time, preserving unassessed releases."""
 if not all(math.isfinite(x) for x in [g,f,h,maximum_error]) or min(g,f,h)<0 or g+f+h>1+1e-12 or not 0<=maximum_error<=1:raise ValueError('Invalid fractions or tolerance')
 c=g+f+h
 if c==0:return result('error among all releases','not_assessable',None,'No released observations')
 lower,upper=f/c,(f+h)/c
 state='met' if upper<=maximum_error else 'not_met' if lower>maximum_error else 'not_assessable'
 return result('error among all releases',state,{'lower':lower,'upper':upper,'assessed_release_fraction':(g+f)/c},'Unassessed releases are allowed to be either correct or incorrect; the conclusion uses the entire compatible interval')
def episode_support(supported,total,*,maximum_unsupported_fraction):
 if not all(math.isfinite(x) for x in [supported,total,maximum_unsupported_fraction]) or int(total)!=total or int(supported)!=supported or total<0 or supported<0 or supported>total or not 0<=maximum_unsupported_fraction<=1:raise ValueError('Invalid event counts or tolerance')
 if total==0:return result('observation of referenced episodes','not_assessable',None,'No eligible reference episodes')
 frac=(total-supported)/total
 return result('observation of referenced episodes','met' if frac<=maximum_unsupported_fraction else 'not_met',{'unsupported_fraction':frac,'eligible_reference_episodes':total},'Observation support only; recognition, false alerts and delay need separate evaluation')
def burden_precision(known_positive,known_duration,intended_duration,*,maximum_width):
 if not all(math.isfinite(x) for x in [known_positive,known_duration,intended_duration,maximum_width]) or not 0<=known_positive<=known_duration<=intended_duration or intended_duration<=0 or not 0<=maximum_width<=1:raise ValueError('Invalid durations or tolerance')
 low=known_positive/intended_duration;high=(known_positive+intended_duration-known_duration)/intended_duration
 return result('full-period binary-state identification width','met' if high-low<=maximum_width+1e-12 else 'not_met',{'lower':low,'upper':high,'width':high-low,'minimum_additional_state_duration':max(0,intended_duration-known_duration-maximum_width*intended_duration)},'Supplied known states are assumed correct; all remaining states are unconstrained')

def main():
 # Boundary tests target denominator/unknown-state errors that would change a claim.
 assert released_error(0,0,0,maximum_error=.1)['status']=='not_assessable'
 assert released_error(.5,0,.5,maximum_error=.1)['status']=='not_assessable'
 assert released_error(.8,.2,0,maximum_error=.1)['status']=='not_met'
 assert released_error(.9,0,.1,maximum_error=.1)['status']=='met'
 assert episode_support(0,0,maximum_unsupported_fraction=.1)['status']=='not_assessable'
 assert episode_support(8,10,maximum_unsupported_fraction=.1)['status']=='not_met'
 assert burden_precision(2,10,10,maximum_width=0)['status']=='met'
 assert burden_precision(0,0,10,maximum_width=.1)['status']=='not_met'
 rows={'fictional_record_all_release_error':released_error(5/12,1/12,2/12,maximum_error=.2),'fictional_record_burden_width':burden_precision(4,10,12,maximum_width=.1),'published_patient48_precision_example':burden_precision(253,2175,2833,maximum_width=.1)}
 root=Path(__file__).resolve().parents[1]
 (root/'source_data/claim_check_examples.json').write_text(json.dumps(rows,indent=2))
 print('Claim checks and unknown-state boundaries passed.')
if __name__=='__main__':main()
