from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
fig=plt.figure(figsize=(7.2,6.4));ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ink='#22313F';teal='#007F78';blue='#28668B';orange='#C46929'
def box(x,y,w,h,text,color='#F0F4F6',size=9):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.009',facecolor=color,edgecolor='#CBD6DD',lw=.8))
 ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,color=ink,linespacing=1.4)
def arrow(x,y,xx,yy):ax.annotate('',xy=(xx,yy),xytext=(x,y),arrowprops={'arrowstyle':'->','color':'#798B97','lw':1})
ax.text(.025,.975,'1  Declare the claim before evaluating the record',color=ink,weight='bold',fontsize=11)
for x,title,detail in [(.03,'Released values','Reference, loss and tolerance'),(.36,'Episode surveillance','Duration, continuity and latency'),(.69,'Full-period burden','Period and required precision')]:
 box(x,.837,.28,.09,title+'\n'+detail,size=8.5)
ax.text(.5,.798,'Shared specification: population, endpoint and intended opportunities',ha='center',fontsize=8.5,color=ink)
arrow(.5,.78,.5,.74)
ax.text(.025,.714,'2  Preserve observation and reference status independently',color=ink,weight='bold',fontsize=11)
left=.04
for width,c,label in [(.32,teal,'G  Assessed, acceptable'),(.18,orange,'F  Assessed error'),(.17,'#D5B571','H  Unassessed'),(.25,'#DEE4E8','U  Unavailable')]:
 ax.add_patch(plt.Rectangle((left,.616),width,.052,color=c,ec='white'))
 ax.text(left+width/2,.642,label,ha='center',va='center',color='white' if c in [teal,orange] else ink,fontsize=8)
 left+=width
ax.text(.5,.583,'G + F + H + U = 1     |     Keep timestamps, causes, latency and version',ha='center',fontsize=8.5,color=ink)
arrow(.5,.57,.5,.529)
ax.text(.025,.504,'3  Apply the check that matches the claim',color=ink,weight='bold',fontsize=11)
for x,text in [(.03,'Assessed error F / (G + F)\nPreserve uncertainty in H'),(.36,'Referenced episodes meeting\nthe declared observation rule'),(.69,'Compatible full-period values\nPrecision and comparison')]:box(x,.369,.28,.09,text,size=8.5)
arrow(.50,.36,.50,.322)
ax.text(.025,.294,'4  Report a conclusion and the evidence needed next',color=ink,weight='bold',fontsize=11)
ax.text(.5,.266,'Every check can return any of the three conclusions',ha='center',fontsize=8,color=ink)
box(.03,.135,.28,.11,'Requirement met\nState its evaluated scope','#E5F1EF',9)
box(.36,.135,.28,.11,'Requirement not met\nIdentify the limiting quantity','#FBEEE2',9)
box(.69,.135,.28,.11,'Not assessable\nIdentify missing evidence','#EEF1F4',9)
ax.text(.5,.074,'Next step: improve estimation, recover observation, obtain reference evidence,\nor justify assumptions and restrict the claim. No composite score.',ha='center',fontsize=8.5,color=ink,linespacing=1.5)
for ext in ['pdf','png']:fig.savefig(ROOT/'figures'/('Fig2.'+ext),dpi=320,bbox_inches='tight')
plt.close(fig)
