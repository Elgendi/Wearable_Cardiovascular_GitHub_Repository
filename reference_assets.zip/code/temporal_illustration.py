"""Real annotated AF timings + imposed masks. No wearable performance is estimated.
Run after downloading AFDB headers/annotations with download_afdb.py, or use included inputs.
"""
from pathlib import Path
import csv,json,hashlib
import numpy as np
import wfdb
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'source_data'; RAW=DATA/'afdb'
protocol=json.loads((DATA/'afdb_protocol.json').read_text())
START,END=protocol['analysis_period_seconds'];T=END-START
records=(RAW/'RECORDS').read_text().split()
# Work in integer ECG sample indices throughout; no resampling of episode boundaries.
def observed_intervals(period,on,phase,end):
 return [(max(0,x),min(end,x+on)) for x in range(-phase,end+period,period) if x+on>0 and x<end]
def intersection(a,b,windows):
 lengths=[max(0,min(b,y)-max(a,x)) for x,y in windows]
 return sum(lengths),max(lengths,default=0)
def write(name,rows):
 with (DATA/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
episodes=[];rows=[];recordinfo=[]
for rec in records:
 if rec in protocol['excluded_records']:continue
 h=wfdb.rdheader(str(RAW/rec));fs=int(h.fs);assert fs==h.fs
 assert h.sig_len>=END*fs
 ann=wfdb.rdann(str(RAW/rec),'atr')
 transitions=[(int(t),s.strip().strip('\x00')) for t,s in zip(ann.sample,ann.aux_note) if s.strip().strip('\x00')]
 assert transitions and transitions[0][0]<=START*fs
 assert set(s for _,s in transitions)<= {'(N','(AFIB','(AFL','(J'}
 af=[];complete=[]
 for j,(a,state) in enumerate(transitions):
  b=transitions[j+1][0] if j+1<len(transitions) else h.sig_len
  if state!='(AFIB' or b<=START*fs or a>=END*fs:continue
  lo=max(a,START*fs)-START*fs;hi=min(b,END*fs)-START*fs
  af.append((lo,hi));full=(a>=START*fs and b<=END*fs and j+1<len(transitions))
  if full:complete.append((lo,hi))
  episodes.append({'record':rec,'onset_sample_in_period':lo,'offset_sample_in_period':hi,'sampling_hz':fs,'duration_s':(hi-lo)/fs,'complete_episode':int(full)})
 total_af=sum(b-a for a,b in af);true_burden=total_af/(T*fs)
 recordinfo.append({'record':rec,'sampling_hz':fs,'header_samples':h.sig_len,'period_s':T,'true_annotated_af_fraction':true_burden,'complete_af_episodes':len(complete)})
 for label,schedule in protocol['schedules'].items():
  for phase in range(0,schedule['period_seconds'],schedule['period_seconds']//60):
   wins=observed_intervals(schedule['period_seconds']*fs,schedule['on_seconds']*fs,phase*fs,T*fs)
   observed=sum(b-a for a,b in wins);assert observed==T*fs//2
   event_observed=sum(intersection(a,b,wins)[0] for a,b in af)
   obs_burden=event_observed/observed;low=event_observed/(T*fs);up=low+.5
   assert low-1e-12<=true_burden<=up+1e-12
   for threshold in [30,120,300,600]:
    eligible=[(a,b) for a,b in complete if b-a>=threshold*fs]
    counts=[intersection(a,b,wins) for a,b in eligible]
    rows.append({'record':rec,'schedule':label,'phase_s':phase,'minimum_episode_s':threshold,'eligible_episodes':len(eligible),'completely_unobserved':sum(z==0 for z,_ in counts),'without_120s_contiguous_observation':sum(m<120*fs for _,m in counts),'coverage':.5,'oracle_released_error':0,'observed_burden':obs_burden,'true_burden':true_burden,'burden_absolute_error':abs(obs_burden-true_burden),'identification_lower':low,'identification_upper':up})
write('afdb_episodes.csv',episodes);write('afdb_records.csv',recordinfo);write('afdb_scenarios.csv',rows)
record_summary=[]
for rec in [r['record'] for r in recordinfo]:
 for duration in [30,120,300,600]:
  for label in protocol['schedules']:
   selected=[r for r in rows if r['record']==rec and r['minimum_episode_s']==duration and r['schedule']==label]
   n=selected[0]['eligible_episodes']
   if not n:continue
   record_summary.append({'record':rec,'minimum_episode_s':duration,'schedule':label,'eligible_episodes':n,'mean_blind_fraction':float(np.mean([r['completely_unobserved']/n for r in selected])),'mean_without_120s_fraction':float(np.mean([r['without_120s_contiguous_observation']/n for r in selected])),'mean_burden_absolute_error':float(np.mean([r['burden_absolute_error'] for r in selected]))})
write('afdb_record_summary.csv',record_summary)
summary={'records':len(recordinfo),'record_hours':len(recordinfo)*T/3600,'complete_episodes':sum(r['complete_af_episodes'] for r in recordinfo),'excluded_records':protocol['excluded_records'],'by_duration':{}}
for d in [30,120,300,600]:
 stats={}
 for label in protocol['schedules']:
  rr=[r for r in record_summary if r['minimum_episode_s']==d and r['schedule']==label]
  stats[label]={'records_with_eligible_episodes':len(rr),'eligible_episodes':sum(r['eligible_episodes'] for r in rr),'median_record_mean_blind_fraction':float(np.median([r['mean_blind_fraction'] for r in rr])),'median_record_mean_without_120s_fraction':float(np.median([r['mean_without_120s_fraction'] for r in rr])),'pooled_phase_mean_blind_fraction':sum(r['mean_blind_fraction']*r['eligible_episodes'] for r in rr)/sum(r['eligible_episodes'] for r in rr)}
 summary['by_duration'][str(d)]=stats
(DATA/'afdb_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Verification against an independent integer-second grid on integer-boundary synthetic episodes.
for period,on in [(120,60),(600,300),(3600,1800)]:
 for phase in [0,60,1740,3540]:
  wins=observed_intervals(period,on,phase,T)
  mask=(np.arange(T)+phase)%period<on
  for a,b in [(0,120),(61,800),(1700,4000),(30000,32400)]:
   got,longest=intersection(a,b,wins);assert got==mask[a:b].sum()
   zz=np.r_[False,mask[a:b],False].astype(int);edges=np.diff(zz)
   lengths=np.where(edges==-1)[0]-np.where(edges==1)[0]
   assert longest==max(lengths,default=0)
# Both primary schedules permit the declared two-minute continuous observation.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,2,figsize=(7.2,4.5))
labels=['five_minute_gaps','long_gaps']
for ax,field,title in zip(axs,['mean_blind_fraction','mean_without_120s_fraction'],['a  Entirely unobserved','b  No continuous two-minute segment']):
 for rec in [r['record'] for r in recordinfo]:
  pair=[next((r for r in record_summary if r['record']==rec and r['minimum_episode_s']==120 and r['schedule']==label),None) for label in labels]
  if None in pair:continue
  ax.plot([0,1],[r[field]*100 for r in pair],color='#A6AFB7',alpha=.65,lw=.9,zorder=1)
  ax.scatter([0,1],[r[field]*100 for r in pair],c=['#007F78','#C46929'],s=16,zorder=2)
 vals=[summary['by_duration']['120'][label]['median_record_'+field] for label in labels]
 for x,v in enumerate(vals):
  ax.plot([x-.11,x+.11],[v*100,v*100],color='#22313F',lw=3,zorder=3)
  ax.annotate(f'{100*v:.1f}%',(x,v*100),xytext=(10,0),textcoords='offset points',fontsize=8,weight='bold',va='center')
 ax.set_xlim(-.28,1.6);ax.set_ylim(-3,103);ax.set_xticks([0,1],['5 min on /\n5 min off','30 min on /\n30 min off']);ax.set_ylabel('Unsupported episodes (%)');ax.set_title(title,loc='left',weight='bold',fontsize=9)
fig.suptitle('Recorded AF timings; imposed schedules; both allow two-minute runs',fontsize=10,weight='bold',y=.98)
fig.text(.5,.015,'Each line: one record, averaged over 60 distinct relative phases. Bars: record medians.\n87 complete AF episodes >=2 min in 15 records; 50% coverage; no detector evaluated.',ha='center',fontsize=8)
fig.subplots_adjust(left=.10,right=.97,top=.86,bottom=.23,wspace=.5)
fig.savefig(ROOT/'figures/FigS1.pdf',bbox_inches='tight');fig.savefig(ROOT/'figures/FigS1.png',dpi=320,bbox_inches='tight');plt.close(fig)
print(json.dumps(summary['by_duration']['120'],indent=2))
