"""Optional independent re-download and input check against the primary article.

Requires requests and lxml. Does not change analysis inputs or retain full text.
Run: python code/check_published_inputs.py
The main reproduction script does not require network access.
"""
import csv
import json
from pathlib import Path
import requests
from lxml import html

root = Path(__file__).resolve().parents[1]
url = 'https://pmc.ncbi.nlm.nih.gov/articles/PMC10545505/'
response = requests.get(url, timeout=60)
response.raise_for_status()
doc = html.fromstring(response.content)
rows25 = None
totals = None
for table in doc.xpath('//table'):
    rows = [[' '.join(c.text_content().split()) for c in row.xpath('./th|./td')]
            for row in table.xpath('.//tr')]
    candidates = [[int(r[0]), int(r[1]), int(r[2].split()[0]), int(r[3]), int(r[4].split()[0])]
                  for r in rows if len(r) == 5 and r[0].isdigit()]
    if len(candidates) == 25:
        rows25 = candidates
    for row in rows:
        if len(row) == 7 and row[0] == 'Total amount in minutes':
            totals = [int(''.join(c.split())) for c in row[1:]]
if rows25 is None or totals is None:
    raise RuntimeError('Primary page structure changed or did not return the article tables.')
with (root/'source_data/reissenberger2023_table2.csv').open() as f:
    saved = list(csv.reader(f))[1:]
assert rows25 == [[int(x) for x in row] for row in saved], 'Published patient rows differ.'
published = json.loads((root/'source_data/reissenberger2023_table3.json').read_text())
assert totals[0] == published['ecg_af_evaluable_min']
assert totals[3] == published['ppg_true_positive_min']
assert totals[4] == published['ppg_false_positive_min']
assert totals[5] == published['ecg_af_outside_evaluable_min']
print('All 25 patient rows and all four aggregate analysis inputs match the primary article.')
