"""Offline reproduction of the complete submission package analyses."""
from pathlib import Path
import subprocess,sys,json,hashlib
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'source_data/afdb/download_manifest.json').read_text())
for item in manifest['files']:
 if 'error' in item:raise RuntimeError(item)
 path=root/'source_data/afdb'/item['filename']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],f'Input changed: {path.name}'
for name in ['reproduce.py','temporal_illustration.py','worked_record.py','claim_checks.py','claim_figure.py','ppg_summary.py']:
 subprocess.run([sys.executable,str(root/'code'/name)],check=True)
print('All reproduction and numerical checks passed; public input hashes match.')
