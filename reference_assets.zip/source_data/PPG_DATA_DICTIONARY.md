# PPG derived feature and summary dictionary

`ppg_epochs.csv` contains one complete, non-overlapping 10-second recorded epoch per row. Separate activity sessions are not contiguous.

| Field | Meaning |
|---|---|
| record | Original PhysioNet record name |
| participant | Original pseudonymous participant identifier |
| activity | sit, walk or run |
| epoch | Zero-based epoch within that recording |
| start_s, end_s | Half-open interval relative to recording start |
| duration_s | Ten seconds for every included epoch |
| ppg_hr_bpm | Fixed spectral-peak HR estimate; no reference input |
| spectral_concentration | Band power near the chosen peak divided by total 0.7–3.5 Hz power |
| reference_available | 1 if supplied ECG annotations pass declared assessment rules; otherwise 0 |
| reference_hr_bpm | Beat-count/span reference estimate when assessable |
| reference_status | Available, annotation-continuity failure, or source-documented ECG-noise caution |

NaN denotes an undefined estimate/reference/summary; it is never a zero heart rate or zero error. The quality gate uses only the PPG estimate and spectral concentration. It does not use ECG assessment or error to decide release.

Participant/activity summary fractions G, F, H and U use all intended complete epochs in their specified subset. Coverage includes unassessed releases. MAE and signed estimator error use only released, reference-assessable epochs. The reference selection shift compares mean ECG HR on those epochs with mean ECG HR on all assessable epochs of the same subset. The sum of this shift and signed estimator error equals the total mean difference. Longest gaps do not bridge separate recordings.

`ppg_record_inventory.csv` records original sample counts, included epoch durations and discarded trailing remainders. `ppg_paired_contrast.csv` gives prespecified threshold-0.7 minus baseline within-person differences; medians of these differences are distinct from differences between group medians.
