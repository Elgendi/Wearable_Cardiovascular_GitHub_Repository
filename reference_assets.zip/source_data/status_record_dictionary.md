# Worked status record data dictionary

All rows are fictional. Dates are arbitrary identifiers, not dates of participant recordings.

| Field | Definition |
|---|---|
| example_id | Fictional record identifier |
| opportunity_id | Unique intended observation opportunity, including unavailable outputs |
| start_utc / end_utc | Non-overlapping half-open interval [start, end), UTC |
| duration_s | Positive interval duration, seconds |
| timely_release | 1 when an output is available within allowed latency; otherwise 0 |
| release_latency_s | Seconds after interval end; blank if no eventual output is represented |
| allowed_latency_s | Declared delivery allowance; 30 seconds in this fictional example |
| release_reason | released, motion_rejection, nonwear or late_delivery |
| reference_available | 1 when synchronized reference state is known |
| reference_state | Binary fictional reference state; blank if unknown |
| released_state | Binary state released in time; blank if no timely state |
| status | G correct assessed release; F erroneous assessed release; H unassessed release; U no timely output |
| processing_version | Identifies the processing rule used |

The endpoint is a fictional binary state. Loss is exact binary disagreement and tolerance is zero; this is not an AF classifier or treatment rule. A late value remains unavailable for the timely-output claim. Missing labels never mean state zero. Actual implementations should add device identifiers, endpoint units and tolerance, reference provenance, wear status, release-policy version and event matching criteria. Do not sum overlapping window lengths to calculate elapsed coverage.
