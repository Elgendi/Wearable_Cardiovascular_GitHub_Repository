# Public source attribution

Headers and manual rhythm annotation files are from George B. Moody and Roger G. Mark, **MIT-BIH Atrial Fibrillation Database**, version 1.0.0, PhysioNet (2000).

- Source: https://physionet.org/content/afdb/1.0.0/
- DOI: https://doi.org/10.13026/C2MW2D
- License: Open Data Commons Attribution License v1.0, https://opendatacommons.org/licenses/by/1-0/
- Original publication: Moody GB, Mark RG. A new method for detecting atrial fibrillation using R-R intervals. Computers in Cardiology 10, 227-230 (1983).
- PhysioNet citation: Pollard et al. PhysioNet as a global platform for biomedical research. Nature Health 1, 792-795 (2026), https://doi.org/10.1038/s44360-026-00096-z.

Downloaded 18 September 2026. File URLs and SHA-256 hashes are recorded in download_manifest.json. No waveform .dat files are included or analysed. Original input bytes are unchanged. Derived intervals and scenario outputs are in the parent directory and are attributed to this source. Imposed schedules and the oracle state reader are constructed by the manuscript analysis; they are not records of wearable performance.
